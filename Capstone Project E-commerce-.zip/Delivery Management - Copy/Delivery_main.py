import pandas as pd
from sklearn.tree import DecisionTreeClassifier
from sklearn.preprocessing import LabelEncoder
from joblib import dump

# Load the dataset
df = pd.read_csv("E_Commerce.csv", encoding='utf-8')

# Apply Label Encoding to the 'Warehouse_block' column
WB = LabelEncoder()
# Transform categorical 'Warehouse_block' data into numerical labels
df['Warehouse_block'] = WB.fit_transform(df['Warehouse_block'])

# Apply Label Encoding to the 'Mode_of_Shipment' column
MoS = LabelEncoder()
# Transform categorical 'Mode_of_Shipment' data into numerical labels
df['Mode_of_Shipment'] = MoS.fit_transform(df['Mode_of_Shipment'])

# Apply Label Encoding to the 'Product_importance' column
Pi = LabelEncoder()
# Transform categorical 'Product_importance' data into numerical labels
df['Product_importance'] = Pi.fit_transform(df['Product_importance'])

# Apply Label Encoding to the 'Gender' column
Gdr = LabelEncoder()
# Transform categorical 'Gender' data into numerical labels
df['Gender'] = Gdr.fit_transform(df['Gender'])

# Select features
selected_features = ['Customer_care_calls', 'Cost_of_the_Product', 'Prior_purchases','Mode_of_Shipment', 'Product_importance','Discount_offered','Weight_in_gms']
X = df[selected_features]
y = df['Reached_on_Time_YN']

# Train the Support Vector Machine model
model = DecisionTreeClassifier(class_weight= None,
                               criterion='gini',
                               max_depth= 4, max_features = 'log2',min_samples_leaf = 7,min_samples_split = 7,splitter= 'best')
model.fit(X, y)

# Save the trained model to a file
dump(model, 'DecisionTreeClassifier.joblib')
