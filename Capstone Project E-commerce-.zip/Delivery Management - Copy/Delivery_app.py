import streamlit as st
from joblib import load

# Load the trained Random Forest model
model = load('DecisionTreeClassifier.joblib')

# Create a Streamlit app
st.title("Delivery Product Delivery Prediction")

# Input fields for feature values on the main screen
st.header("Enter Information")
Customer_care_calls = st.number_input('Customer Care Calls', min_value = 0, max_value=100, value=1)
Cost_of_the_Product = st.number_input('Cost of the Product',min_value = 5, max_value=20000)
Prior_purchases = st.number_input('Prior Purchases',min_value = 0, max_value=20)
Product_importance = st.selectbox('Product Importance', ['low', 'medium', 'high'])
Discount_offered = st.number_input('Discount Offered', min_value = 0, max_value=500)
Weight_in_gms = st.number_input('Weight in grams')
Mode_of_Shipment = st.selectbox('Mode_of_Shipment', ['Ship', 'Flight', 'Road'])



# Map input values to numeric using the label mapping
label_mapping = {
    'low': 1,
    'medium': 2,
    'high': 0,
    'Ship': 2,
    'Flight': 0,
    'Road': 1,
}
Product_importance= label_mapping[Product_importance]
Mode_of_Shipment = label_mapping[Mode_of_Shipment]

# Make a prediction using the model
prediction = model.predict([[Customer_care_calls,Cost_of_the_Product,Prior_purchases,Mode_of_Shipment,Product_importance,Discount_offered,Weight_in_gms]])

# Display the prediction result on the main screen
if st.button('Predict'):
    input_data = [[Customer_care_calls,Cost_of_the_Product,Prior_purchases,Mode_of_Shipment,Product_importance,Discount_offered,Weight_in_gms]]
    prediction = model.predict(input_data)
    st.write(f'Delivery received on Time: {prediction}')


